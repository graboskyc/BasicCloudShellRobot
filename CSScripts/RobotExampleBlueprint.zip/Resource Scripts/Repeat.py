import os
import time
import datetime
import json

# parse inputs

print os.environ["TEXT"]