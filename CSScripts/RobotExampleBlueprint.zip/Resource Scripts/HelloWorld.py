import os
import time
import datetime
import json

# parse inputs
print "Hello World 12345!"